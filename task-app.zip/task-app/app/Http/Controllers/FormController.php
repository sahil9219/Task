<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Validator;

use Illuminate\Support\Facades\DB;

class FormController extends Controller
{
    
    public function index()
    {
        return view('form.index');
    }

    public function save(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'name'=>'required',
            'email'=>'required|email|unique:users',
            'password'=>'required',
            'description'=>'required',
            'fav_language'=>'required',
            'vehicle'=>'required',
            'cars'=>'required',
            'image'=>'required'
        ]);

        if (!$validator->passes()) {
            return response()->json(['status'=>0, 'error'=>$validator->errors()->toArray()]);
        }else{
            if ($request->hasFile('image')) {
                $file = $request->file('image');
                $extenssion = $file->getClientOriginalExtension();
                $filename = time() . '.' .$extenssion;
                $file->move('uploads/user/', $filename);

            }

            $values = [
                'name'=>$request->name,
                'email'=>$request->email,
                'password'=>$request->password,
                'description'=>$request->description,
                'fav_language'=>$request->fav_language,
                'vehicle'=>$request->vehicle,
                'cars'=>$request->cars,
                'image'=>$filename
            ];

            

            $query = DB::table('users')->insert($values);

            if ($query) {
               return response()->json(['status'=>1, 'msg'=>'New User has been Successfully Inserted']);
            }
        }
    }

}
