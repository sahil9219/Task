<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>

    <div class="container">
        <div class="row" style="margin: top 45px;">
            <div class="col-md-4 col-md-offset-4">
                <h4>Add New User</h4>
                <form action="{{ route('form.save') }}" method="post" id="main_form">
                    @csrf
                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text" class="form-control" name="name" placeholder="Enter Your Name Here">
                        <span class="text-danger error-text name_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" class="form-control" name="email" placeholder="Enter Your Email Here">
                        <span class="text-danger error-text email_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="">Description</label>
                        <textarea id="description" name="description" rows="10" cols="50">
                        </textarea>
                        <span class="text-danger error-text description_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password" class="form-control" name="password" placeholder="Enter Your Password Here">
                        <span class="text-danger error-text password_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="">Image</label>
                        <input type="file" class="form-control" name="image" placeholder="Enter Your Password Here">
                        <span class="text-danger error-text image_error"></span>
                    </div>
                    <div class="form-group">
                    <p>Choose your favorite Web language:</p>
                        <input type="radio" id="html" name="fav_language" value="HTML">
                        <label for="html">HTML</label><br>
                        <input type="radio" id="css" name="fav_language" value="CSS">
                        <label for="css">CSS</label><br>
                        <input type="radio" id="javascript" name="fav_language" value="JavaScript">
                        <label for="javascript">JavaScript</label><br>
                        <span class="text-danger error-text fav_language_error"></span>
                    </div>

                    <div class="form-group">
                        <h4>Checkboxes</h4>
                        <input type="checkbox" id="vehicle1" name="vehicle" value="Bike">
                        <label for="vehicle1"> I have a bike</label><br>
                        <input type="checkbox" id="vehicle2" name="vehicle" value="Car">
                        <label for="vehicle2"> I have a car</label><br>
                        <input type="checkbox" id="vehicle3" name="vehicle" value="Boat">
                        <label for="vehicle3"> I have a boat</label><br>
                        <span class="text-danger error-text vehicle_error"></span>
                    </div>

                    <div class="form-group">
                        <label for="cars">Choose a car:</label>
                        <select name="cars" id="cars" class="required">
                            <option value="">Select From List Below</option>
                            <option value="saab">Saab</option>
                            <option value="mercedes">Mercedes</option>
                            <option value="audi">Audi</option>
                        </select><br>
                        <span class="text-danger error-text cars_error"></span>
                    </div>

                    <button type="submit" class="btn btn-block btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>

<script
  src="https://code.jquery.com/jquery-3.6.0.js"
  integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
  crossorigin="anonymous">
</script>

<script>
    $(function(){
        $("#main_form").on('submit', function(e){
            e.preventDefault();

            $.ajax({
                url:$(this).attr('action'),
                method:$(this).attr('method'),
                data:new FormData(this),
                processData:false,
                dataType:'json',
                contentType:false,
                beforeSend:function(){
                    $(document).find('span.error-text').text('');
                },
                success:function(data){
                    if(data.status == 0){
                        $.each(data.error, function(prefix, val){
                            $('span.'+prefix+'_error').text(val[0]);
                        });
                    }else{
                        $("#main_form")[0].reset();
                        alert(data.msg);
                    }
                }
            });

        });
    });
</script>
    
</body>
</html>